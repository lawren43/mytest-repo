#!/bin/bash

java -classpath ./bin -jar machineagent.jar 