(
cd solaris
bash ./core.sh
)
